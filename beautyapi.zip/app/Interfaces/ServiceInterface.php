<?php


namespace App\Interfaces;

/**
 * Interface ServiceInterface
 * @package App\Interfaces
 */
interface ServiceInterface extends BaseInterface
{

}
