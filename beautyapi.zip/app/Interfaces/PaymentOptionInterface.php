<?php


namespace App\Interfaces;

/**
 * Interface PaymentOption
 * @package App\Interfaces
 */
interface PaymentOptionInterface extends BaseInterface
{

}
