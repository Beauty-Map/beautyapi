<?php


namespace App\Interfaces;

/**
 * Interface Province
 * @package App\Interfaces
 */
interface ProvinceInterface extends BaseInterface
{

}
