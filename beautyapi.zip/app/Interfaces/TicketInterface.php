<?php


namespace App\Interfaces;

/**
 * Interface TicketInterface
 * @package App\Interfaces
 */
interface TicketInterface extends BaseInterface
{

}
