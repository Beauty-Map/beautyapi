<?php


namespace App\Interfaces;

/**
 * Interface IntroInterface
 * @package App\Interfaces
 */
interface IntroInterface extends BaseInterface
{

}
