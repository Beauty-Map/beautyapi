<?php


namespace App\Interfaces;

/**
 * Interface PlanInterface
 * @package App\Interfaces
 */
interface PlanInterface extends BaseInterface
{

}
