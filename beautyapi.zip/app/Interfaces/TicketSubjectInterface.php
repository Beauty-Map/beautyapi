<?php


namespace App\Interfaces;

/**
 * Interface TicketSubjectInterface
 * @package App\Interfaces
 */
interface TicketSubjectInterface extends BaseInterface
{

}
