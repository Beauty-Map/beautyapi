<?php


namespace App\Interfaces;

/**
 * Interface WalletInterface
 * @package App\Interfaces
 */
interface WalletInterface extends BaseInterface
{

}
